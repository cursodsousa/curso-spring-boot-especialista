package io.github.cursodsousa.sbootexpsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootexpSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
