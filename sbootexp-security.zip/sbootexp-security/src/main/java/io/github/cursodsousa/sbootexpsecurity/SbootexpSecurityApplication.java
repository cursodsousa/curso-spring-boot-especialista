package io.github.cursodsousa.sbootexpsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootexpSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootexpSecurityApplication.class, args);
	}

}
