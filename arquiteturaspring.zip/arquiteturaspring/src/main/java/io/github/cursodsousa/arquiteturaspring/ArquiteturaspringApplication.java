package io.github.cursodsousa.arquiteturaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquiteturaspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquiteturaspringApplication.class, args);
	}

}
