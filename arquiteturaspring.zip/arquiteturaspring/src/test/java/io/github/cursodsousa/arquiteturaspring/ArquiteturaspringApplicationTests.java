package io.github.cursodsousa.arquiteturaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquiteturaspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
